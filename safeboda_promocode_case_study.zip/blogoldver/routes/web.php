<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::get('/documentation', function () {
    return view('documentation');
});


Route::GET('/create_promocodes/{number_of_promo_codes}','api_requests@create_promocodes');

Route::GET('/set_ride_amount/{promo_code}/{ride_amount}','api_requests@set_ride_amount');

Route::GET('/set_promocode_expiry/{promo_code}/{expiry_date}','api_requests@set_promocode_expiry');

Route::GET('/set_promocode_status/{promo_code}','api_requests@set_promocode_status');

Route::GET('/request_for_active_promocodes','api_requests@request_for_active_promocodes');

Route::GET('/request_for_all_promocodes','api_requests@request_for_all_promocodes');

Route::GET('/check_if_requested_destination_is_valid/{promo_code_requested}/{promo_code_longitude}/{promo_code_latitude}','api_requests@check_if_requested_destination_is_valid');

Route::GET('/set_promocode_radius/{promo_code}/{radius}','api_requests@set_promocode_radius');

Route::GET('/test_validity_of_promo_code/{promo_code_requested}/{origin_longitude}/{origin_latitude}/{destination_longitude}/{destination_latitude}','api_requests@test_validity_of_promo_code');

Route::GET('/promocode_details_with_polyline/{promo_code_requested}/{origin_longitude}/{origin_latitude}/{destination_longitude}/{destination_latitude}','api_requests@promocode_details_with_polyline');