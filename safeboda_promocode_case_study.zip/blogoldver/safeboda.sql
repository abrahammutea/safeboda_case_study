-- phpMyAdmin SQL Dump
-- version 4.6.5.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 07, 2021 at 06:28 PM
-- Server version: 10.1.21-MariaDB
-- PHP Version: 7.1.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+03:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `safeboda`
--

-- --------------------------------------------------------

--
-- Table structure for table `promocodes`
--

CREATE TABLE `promocodes` (
  `promo_id` int(224) NOT NULL,
  `promo_code` varchar(10) NOT NULL,
  `date_created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `promo_longitude` varchar(20) NOT NULL,
  `promo_latitude` varchar(30) NOT NULL,
  `promo_code_amount_worth` varchar(224) NOT NULL,
  `promo_expiry_date` varchar(30) NOT NULL,
  `promo_radius` varchar(20) NOT NULL,
  `promo_status` varchar(10) NOT NULL,
  `updated_at` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `promocodes`
--

INSERT INTO `promocodes` (`promo_id`, `promo_code`, `date_created`, `promo_longitude`, `promo_latitude`, `promo_code_amount_worth`, `promo_expiry_date`, `promo_radius`, `promo_status`, `updated_at`) VALUES
(1, '1212', '2021-06-15 21:00:00', '0.096866', '37.515413', '55', '2001-03-10', '102', 'INACTIVE', '2021-06-07 10:37:38'),
(2, '12321', '2021-06-15 21:00:00', '0.083830', '37.353129', '200', '12/10/2021', '140', 'INACTIVE', '2021-06-07 09:17:45'),
(3, '51712151', '2021-06-07 01:10:31', '43243243', '0', '200', '12/12/2021', '121', 'INACTIVE', '2021-06-07 08:54:08'),
(4, '84139412', '2021-06-07 01:10:31', '432432432', '0', '200', '12/12/2021', '121', 'INACTIVE', '2021-06-07 09:49:01'),
(5, '80979326', '2021-06-07 01:10:31', '432432432', '0', '200', '12/12/2021', '121', 'ACTIVE', ''),
(6, '29159206', '2021-06-07 01:10:31', '4324324324', '0', '200', '12/12/2021', '121', 'INACTIVE', '2021-06-07 09:57:02'),
(7, '39770532', '2021-06-07 01:10:31', '4324324324', '0', '200', '12/12/2021', '121', 'INACTIVE', '2021-06-07 09:57:31'),
(8, '80064561', '2021-06-07 01:10:31', '43243243243', '0', '200', '12/12/2021', '121', 'ACTIVE', ''),
(9, '48407372', '2021-06-07 01:10:31', '43243243243', '0', '200', '12/12/2021', '121', 'ACTIVE', ''),
(10, '45100860', '2021-06-07 01:10:57', '4324324324', '0', '200', '12/12/2021', '121', 'ACTIVE', ''),
(11, '39645904', '2021-06-07 01:10:57', '4324324324', '0', '200', '12/12/2021', '121', 'ACTIVE', ''),
(12, '14367767', '2021-06-07 01:10:57', '43243243243', '0', '200', '12/12/2021', '121', 'ACTIVE', ''),
(13, '28229676', '2021-06-07 01:10:57', '4324324324', '0', '200', '12/12/2021', '121', 'ACTIVE', ''),
(14, '71193662', '2021-06-07 01:10:57', '4324324324', '0', '200', '12/12/2021', '121', 'ACTIVE', ''),
(15, '54062053', '2021-06-07 01:10:57', '43243243243', '0', '200', '12/12/2021', '121', 'ACTIVE', ''),
(16, '17488139', '2021-06-07 01:10:57', '43243243243', '0', '200', '12/12/2021', '121', 'INACTIVE', ''),
(17, '26920507', '2021-06-07 13:52:12', '', '', '', '', '', 'ACTIVE', ''),
(18, '91033504', '2021-06-07 13:52:12', '', '', '', '', '', 'ACTIVE', ''),
(19, '72178905', '2021-06-07 13:52:12', '', '', '', '', '', 'ACTIVE', ''),
(20, '62200275', '2021-06-07 13:52:12', '', '', '', '', '', 'ACTIVE', ''),
(21, '01670524', '2021-06-07 13:52:12', '', '', '', '', '', 'ACTIVE', ''),
(22, '56710043', '2021-06-07 13:52:12', '', '', '', '', '', 'ACTIVE', ''),
(23, '94222707', '2021-06-07 13:52:12', '', '', '', '', '', 'ACTIVE', ''),
(24, '31577471', '2021-06-07 13:52:55', '', '', '', '', '', 'ACTIVE', ''),
(25, '85168696', '2021-06-07 13:52:55', '', '', '', '', '', 'ACTIVE', ''),
(26, '47905173', '2021-06-07 13:52:55', '', '', '', '', '', 'ACTIVE', ''),
(27, '99309040', '2021-06-07 13:52:55', '', '', '', '', '', 'ACTIVE', ''),
(28, '04506138', '2021-06-07 13:52:55', '', '', '', '', '', 'ACTIVE', ''),
(29, '08450861', '2021-06-07 13:52:55', '', '', '', '', '', 'ACTIVE', ''),
(30, '93202485', '2021-06-07 13:52:55', '', '', '', '', '', 'ACTIVE', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `promocodes`
--
ALTER TABLE `promocodes`
  ADD PRIMARY KEY (`promo_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `promocodes`
--
ALTER TABLE `promocodes`
  MODIFY `promo_id` int(224) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
