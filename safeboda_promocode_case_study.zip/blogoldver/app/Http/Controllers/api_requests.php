<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\Http\Requests;

use App\Http\Controllers\Controller;
use App\db_request_promocodes;
use App\Http\Controllers\Polyline;

class api_requests extends Controller
{
    function create_promocodes(Request $number_of_promo_codes){
        //This function will accept a value as input. 
        //This value will create the requested number of unique promocodes

        foreach($number_of_promo_codes as $promo_codes){
            $temp_promo_code=substr(uniqid('',true),-8);
            $create_promo_codes=db_request_promocodes::insert(['promo_code' => $temp_promo_code,'promo_longitude' => "",'promo_latitude' => "",'promo_code_amount_worth' => "",'promo_expiry_date' => "",'promo_radius' => "",'promo_status' => 'ACTIVE','updated_at'=>""]);
            $temp_promo_code='';
        }
        
        if(!$create_promo_codes){
            $message="Failed";
            $output=array('message'=>$message);
            return(json_encode($output));
        }
        else{
            $message="success";
            $output=array('message'=>$message);
            return(json_encode($output));
        }
    }

    function set_ride_amount(Request $request){
        //This function will update a specific promo code with the new ride amount,and will accept two input values. 
            //1. The promo_code to be set.
            //2. The amount of the ride.

        $update_promo_code_state=db_request_promocodes::where('promo_code',$request->promo_code)->update(['promo_code_amount_worth'=>$request->ride_amount]);

        if(!$update_promo_code_state){
            $message="Failed";
            $output=array('message'=>$message);
            return(json_encode($output));
        }
        else{
            $message="success";
            $output=array('message'=>$message);
            return(json_encode($output));
        }
    }

    function set_promocode_expiry(Request $request){
        //This function will accept two input values. 
            //1. The promo_code to be updated.
            //2. The date the promoocode will expire.
        //We will be using the date format "Y-m-d". e.g 2001-03-10

        $update_promo_code_state=db_request_promocodes::where('promo_code',$request->promo_code)->update(['promo_expiry_date'=>$request->expiry_date]);

        if(!$update_promo_code_state){
            $message="Failed";
            $output=array('message'=>$message);
            return(json_encode($output));
        }
        else{
            $message="success";
            $output=array('message'=>$message);
            return(json_encode($output));
        }
    }
        
    function set_promocode_status(request $request){
        //This function will accept one input value. 
            //1. The id of the promo code to be updated.

        $update_promo_code_state=db_request_promocodes::where('promo_code',$request->promo_code)->update(['promo_status'=>'INACTIVE']);

        if(!$update_promo_code_state){
            $message="Failed";
            $output=array('message'=>$message);
            return(json_encode($output));
        }
        else{
            $message="success";
            $output=array('message'=>$message);
            return(json_encode($output));
        }
    }
        
    function request_for_active_promocodes(){
        //This function will request for all active promocodes.
        
        $promo_codes=db_request_promocodes::select('date_created','promo_longitude','promo_latitude','promo_code','promo_code_amount_worth','promo_expiry_date','promo_radius','promo_status','promo_id')->where('promo_status','=','ACTIVE')->get();

        if(!$promo_codes){
            $message="Failed";
            $output=array('message'=>$message);
            return(json_encode($output));
        }
        else{
            $message="success";
            $output=array('message'=>$message,'promo_codes'=>$promo_codes);
            return(json_encode($output));
        }
    }
    
    function request_for_all_promocodes(){
        //This function will request for all promocodes.
        $promo_codes=db_request_promocodes::select('date_created','promo_longitude','promo_latitude','promo_code','promo_code_amount_worth','promo_expiry_date','promo_radius','promo_status','promo_id')->get();


        if(!$promo_codes){
            $message="Failed";
            $output=array('message'=>$message);
            return(json_encode($output));
        }
        else{
            $message="success";
            $output=array('message'=>$message,'promo_codes'=>$promo_codes);
            return(json_encode($output));
        }
    }

    function check_if_requested_destination_is_valid(request $request){     
        //This function will check if the requested destination is valid.
        //It will calculate the distance between the gps points and evaluate if it is within the radius set in the database.
        
        $promo_codes=db_request_promocodes::select('promo_longitude','promo_latitude','promo_radius')->where('promo_code','=',$request->promo_code_requested)->get();
        
        $event_location_longitude=$promo_codes[0]['promo_longitude'];
        $event_location_latitude=$promo_codes[0]['promo_latitude'];

        $destination_location_longitude=$request->promo_code_longitude;
        $destination_location_latitude=$request->promo_code_latitude;

        $longitude_difference=$event_location_longitude-$destination_location_longitude;
        $distance = sin(deg2rad($event_location_latitude)) * sin(deg2rad($destination_location_latitude)) +  cos(deg2rad($event_location_latitude)) * cos(deg2rad($destination_location_latitude)) * cos(deg2rad($longitude_difference));
        $distance = acos($distance);
        $distance = rad2deg($distance);
        $distance_in_kilometers=($distance * 60 * 1.1515)*1.609344;

        if($distance_in_kilometers>$promo_codes[0]['promo_radius']){
            //The destination or pickup point is out of the radius for the promo_code
            $message="Failed. Destination is not within the set radius";
            $output=array('message'=>$message,'distance_in_kilometers'=>$distance_in_kilometers);
            return(json_encode($output));
        }
        else{
            //The destination or pickup point is WITHIN the radius for the promo_code
            $message="success";
            $output=array('message'=>$message,'distance_in_kilometers'=>$distance_in_kilometers);
            return(json_encode($output));
        }
    }
    
    function set_promocode_radius(request $request){
        //This function will set a specific radius for the requested promocode.
        //It will accept 2 input values
            //1. The promo code to be edited
            //2. The new radius to be set for the promo code.
    
        $update_promo_code_state=db_request_promocodes::where('promo_code',$request->promo_code)->update(['promo_radius'=>$request->radius]);

        if(!$update_promo_code_state){
            $message="Failed";
            $output=array('message'=>$message);
            return(json_encode($output));
        }
        else{
            $message="success";
            $output=array('message'=>$message);
            return(json_encode($output));
        }
    }
    
    function test_validity_of_promo_code(request $request){
        //This function will set a specific radius for the requested promocode.
        //It will accept 5 input values
            //1. The longitude gps cordinates of the origin
            //2. The latitude gps cordinates of the origin
            //3. The longitude gps cordinates of the destination
            //4. The latitude gps cordinates of the destination
            //5.  The promo code to be validated
    
        $test_promo_code_validity=db_request_promocodes::select('promo_longitude','promo_latitude','promo_radius')->where('promo_code','=',$request->promo_code_requested)->get();
        
        if($test_promo_code_validity){
            //The promo code is registered in the database

            //Using the radius set in the database, we will evaluate if the distance between the origin and destination is within the promo code radius.
            $promo_code_longitude=$test_promo_code_validity[0]['promo_longitude'];
            $promo_code_latitude=$test_promo_code_validity[0]['promo_latitude'];
            $promo_code_radius=$test_promo_code_validity[0]['promo_radius'];
    
            $origin_longitude=$request->origin_longitude;
            $origin_latitude=$request->origin_latitude;

            $destination_longitude=$request->destination_longitude;
            $destination_latitude=$request->destination_latitude;

            
            $longitude_difference=$origin_longitude-$destination_longitude;
            $distance = sin(deg2rad($origin_latitude)) * sin(deg2rad($destination_latitude)) +  cos(deg2rad($origin_latitude)) * cos(deg2rad($destination_latitude)) * cos(deg2rad($longitude_difference));
            $distance = acos($distance);
            $distance = rad2deg($distance);
            $distance_in_kilometers=($distance * 60 * 1.1515)*1.609344;

            if($distance_in_kilometers<$test_promo_code_validity[0]['promo_radius']){
                //The destination is within the promo_code radius

                $message="The promocode is valid and the provided destination is within the promocode radius.";
                $output=array('message'=>$message,'distance_in_kilometers'=>$distance_in_kilometers);
                return(json_encode($output));
            }
            else{
                $message="The promocode is valid BUT the provided destination is NOT within the promocode radius.";
                $output=array('message'=>$message,'distance_in_kilometers'=>$distance_in_kilometers);
                return(json_encode($output));
            }
        }
        else{
            //The promocode code is NOT registered in the database
            
            $message="Failed. The promocode is not valid. Kindly try again";
            $output=array('message'=>$message);
            return(json_encode($output));
        }    
    }

    function promocode_details_with_polyline(request $request){
        $promo_codes=db_request_promocodes::select('promo_id','date_created','promo_longitude','promo_latitude','promo_code','promo_code_amount_worth','promo_expiry_date','promo_radius','promo_status')
            ->where('promo_code','=',$request->promo_code_requested)->get();
        if($promo_codes){
            //The promo_code is valid
            
            $points = array(
                array($request->origin_longitude,$request->origin_latitude),
                array($request->destination_longitude,$request->destination_latitude)
            );
            $encoded = Polyline::encode($points);

            $message="The promo_code is valid.";
            $output=array('message'=>$message,'ecoded'=>$encoded,'promo_codes'=>$promo_codes);
            return(json_encode($output));
        }
        else{
            //The promo_code is not valid
            $message="Failed. The promocode is not valid. Kindly try again";
            $output=array('message'=>$message);
            return(json_encode($output));
        }
    }
}