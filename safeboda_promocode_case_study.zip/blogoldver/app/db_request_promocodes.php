<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class db_request_promocodes extends Model
{
    //Table Name
    protected $table = 'promocodes';
    //Primary Key
    protected $primaryKey = 'promo_id';
    public $promo_code = 'promo_code';
    //Timestamps
    public $timestamps = true;    
}
