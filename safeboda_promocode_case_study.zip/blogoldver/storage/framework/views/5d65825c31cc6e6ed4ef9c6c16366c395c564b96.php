<!doctype html>
<html lang="<?php echo e(app()->getLocale()); ?>">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Abraham Mutea</title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Raleway:100,600" rel="stylesheet" type="text/css">

        <!-- Styles -->
        <style>
            html, body {
                background-color: #fff;
                color: #636b6f;
                font-family: 'Raleway', sans-serif;
                font-weight: 100;
                height: 100vh;
                margin: 0;
            }

            .full-height {
                height: 100vh;
            }

            .flex-center {
                align-items: center;
                display: flex;
                justify-content: center;
            }

            .position-ref {
                position: relative;
            }

            .top-right {
                position: absolute;
                right: 10px;
                top: 18px;
            }

            .content {
                text-align: center;
            }

            .title {
                font-size: 84px;
            }

            .links > a {
                color: #636b6f;
                padding: 0 25px;
                font-size: 12px;
                font-weight: 600;
                letter-spacing: .1rem;
                text-decoration: none;
                text-transform: uppercase;
            }

            .m-b-md {
                margin-bottom: 30px;
            }
            .spacing-left{
                margin-left:25px;
                margin-top:20px;
            }
            .spacing-left-double{
                margin-left:45px;
            }
        </style>
    </head>
    <body>
        <div class="flex position-ref full-height" style="color:#000;font-family: initial;font-weight: 100;font-size: 17px;">
            <div class="content">
                <div style="width:100%;padding:15px 15px;text-align:left">
                    <p>This is the structure of the code</p>
                    <p>api/</p>
                    <div class="spacing-left">
                        /routes<br>
                            <div class="spacing-left-double">
                                /web.php (This has all the routes)
                            </div>
                    </div>
                    <div class="spacing-left">
                        /app<br>
                            <div class="spacing-left-double">
                                /db_request_promocodes.php (This model connects the application to the table promocodes)
                            </div>
                            
                            <div class="spacing-left-double">
                                /Http/controllers
                                <div class="spacing-left-double">
                                    /api_requests.php (This is the controller. It processes and returns requests)
                                </div>
                                <div class="spacing-left-double">
                                    /Polyline.php (This controller supports the calculation of the polyline)
                                </div>
                            </div>
                    </div>
                    <div class="spacing-left">
                        /safeboda.sql<br>
                            <div class="spacing-left-double">
                                This contains the database
                            </div>
                    </div>
                    <div class="spacing-left">
                        /resources<br>
                            <div class="spacing-left-double">
                                /welcome.blade.php
                            </div>
                            <div class="spacing-left-double">
                                /documentation.blade.php
                            </div>
                    </div>
                </div>
            </div>
        </div>
    </body>
</html>
