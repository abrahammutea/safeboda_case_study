# Examples

A small collection of solutions to common problems. Each example should be a
bare-bone / self contained object.

 - [Well-Known Binary](WellKnownBinary) converter.
 - Preview encoded strings with a [SVG transcoder](EncodedToSVG).
